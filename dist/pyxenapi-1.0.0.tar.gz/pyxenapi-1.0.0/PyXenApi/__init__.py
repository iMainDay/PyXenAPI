"""
:author: MaiNDaY
:license: Apache License, v2.0
"""

from .xenforoapi import XenForoAPI
